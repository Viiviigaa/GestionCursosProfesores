-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 07-02-2026 a las 01:22:44
-- Versión del servidor: 8.0.45-0ubuntu0.24.04.1
-- Versión de PHP: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cursoscp`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin`
--

CREATE TABLE `admin` (
  `usuario` varchar(50) NOT NULL,
  `contraseña` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `admin`
--

INSERT INTO `admin` (`usuario`, `contraseña`) VALUES
('root', 'root');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos`
--

CREATE TABLE `cursos` (
  `codigo` smallint NOT NULL,
  `nombre` varchar(50) NOT NULL DEFAULT '',
  `abierto` tinyint(1) NOT NULL DEFAULT '1',
  `numeroplazas` smallint NOT NULL DEFAULT '20',
  `plazoinscripcion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `cursos`
--

INSERT INTO `cursos` (`codigo`, `nombre`, `abierto`, `numeroplazas`, `plazoinscripcion`) VALUES
(2, 'Administracion avanzada de Apache', 0, 30, '2015-05-20'),
(3, 'Elaboracion de recursos didacticos', 1, 20, '2015-05-20'),
(4, 'Uso didactico de Moodle en primaria', 0, 10, '2015-05-20'),
(5, 'Uso didactico de Moodle en secundaria', 1, 20, '2015-01-20'),
(6, 'Moodle y el aula de musica', 1, 20, '2015-05-25'),
(10, 'Gran Canaria', 1, 5, '2026-02-09');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitantes`
--

CREATE TABLE `solicitantes` (
  `dni` varchar(9) NOT NULL DEFAULT '',
  `apellidos` varchar(40) NOT NULL DEFAULT '',
  `nombre` varchar(20) NOT NULL DEFAULT '',
  `telefono` varchar(12) NOT NULL DEFAULT '',
  `correo` varchar(50) NOT NULL DEFAULT '',
  `codcen` varchar(8) NOT NULL DEFAULT '',
  `coordinadortic` tinyint(1) NOT NULL DEFAULT '0',
  `grupotic` tinyint(1) NOT NULL DEFAULT '0',
  `nomgrupo` varchar(25) NOT NULL DEFAULT '',
  `pbilin` tinyint(1) NOT NULL DEFAULT '0',
  `cargo` tinyint(1) NOT NULL DEFAULT '0',
  `nombrecargo` varchar(15) NOT NULL DEFAULT '',
  `situacion` enum('activo','inactivo') NOT NULL DEFAULT 'activo',
  `fechanac` date DEFAULT NULL,
  `especialidad` varchar(50) NOT NULL DEFAULT '',
  `puntos` tinyint UNSIGNED DEFAULT '0',
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `solicitantes`
--

INSERT INTO `solicitantes` (`dni`, `apellidos`, `nombre`, `telefono`, `correo`, `codcen`, `coordinadortic`, `grupotic`, `nomgrupo`, `pbilin`, `cargo`, `nombrecargo`, `situacion`, `fechanac`, `especialidad`, `puntos`, `password`) VALUES
('11111111Q', 'Martin', 'Ivan', '699399155', 'ivan@informaticascarlatti.es', '28300283', 1, 0, 'DAW', 0, 0, 'director', 'activo', '2019-01-15', 'Java', 13, '12345678'),
('22222222T', 'Delgado', 'Diego', '688523142', 'diego@informaticascarlatti.es', '28300283', 1, 0, 'DAW', 0, 0, 'profesor', 'inactivo', '2022-10-15', 'Sistemas', 10, '12345678'),
('50415114E', 'Villanueva', 'Alvaro', '645414245', 'alvaro@informaticascarlatti.es', '28300283', 0, 0, 'Informatica', 1, 0, 'director', 'activo', '2000-01-14', 'brawl', 14, '1234'),
('50544748Q', 'Ortega', 'Javier', '647142423', 'ortega@gmail.es', '28300', 1, 1, 'DAW', 0, 0, 'Profesor', 'activo', '1980-09-02', 'informatica', 0, '12345678');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `dni` varchar(9) NOT NULL DEFAULT '',
  `codigocurso` smallint NOT NULL DEFAULT '0',
  `fechasolicitud` date NOT NULL,
  `admitido` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Volcado de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`dni`, `codigocurso`, `fechasolicitud`, `admitido`) VALUES
('11111111Q', 2, '2026-02-06', 0),
('12312311T', 3, '2026-02-06', 0),
('12312311T', 10, '2026-02-06', 0),
('22222222T', 2, '2026-02-06', 0),
('50415114E', 2, '2026-02-06', 0),
('50544748Q', 2, '2026-02-06', 0),
('50544748Q', 3, '2026-02-06', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `solicitantes`
--
ALTER TABLE `solicitantes`
  ADD PRIMARY KEY (`dni`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`dni`,`codigocurso`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cursos`
--
ALTER TABLE `cursos`
  MODIFY `codigo` smallint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
