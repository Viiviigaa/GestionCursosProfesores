<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Document</title>
    <?php
        $con = new PDO('mysql:host=localhost;dbname=cursoscp;charset=utf8', 'victor', '1234');
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        if($_SERVER['REQUEST_METHOD'] == 'POST'){

            $nombreCurso = $_POST['nombreCurso'];
            $activo = isset($_POST['activo']) ? 1 : 0;
            $plazas = $_POST['numPlazas'];
            $plazo = $_POST['inscripcion'];

            try {
                $consulta = "INSERT INTO cursos (nombre, abierto, numeroplazas, plazoinscripcion) VALUES (?, ?, ?, ?)";
                $stmt = $con->prepare($consulta);
                $stmt->execute([$nombreCurso, $activo, $plazas, $plazo]);            
                } catch (PDOException $e) {
                    echo "<h4 style='color:red'>Error al insertar: " . $e->getMessage() . "</h4>";
                }
            }
    ?> 
</head>
<body>
    <h3>Cursos</h3>
    <table>
            <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Abierto</th>
                <th>Número de plazas</th>
                <th>Plazo de inscripción</th>
                <th>Activar/Desactivar</th>
                <th>Eliminar</th>
            </tr>
                <?php 
                    $stmt = $con->query("SELECT * FROM cursos");
                    $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    foreach($cursos as $curso){
                        echo "<tr>";
                        echo "<td>{$curso['codigo']}</td>";
                        echo "<td>{$curso['nombre']}</td>";
                        echo "<td>{$curso['abierto']}</td>";
                        echo "<td>{$curso['numeroplazas']}</td>";
                        echo "<td>{$curso['plazoinscripcion']}</td>";
                        if($curso['abierto']){
                            echo "<td>
                                <form action='actualizar.php' method='post'>
                                <input type='hidden' name='code' value='". $curso['codigo']."'>
                                <input type='hidden' name='activo' value='". $curso['abierto']."'>
                                <input type='submit' value='Desactivar'>
                                </form>
                            </td>";
                        }else if(!$curso['abierto']){
                            echo "<td>
                                <form action='actualizar.php' method='post'>
                                <input type='hidden' name='code' value='". $curso['codigo']."'>
                                <input type='hidden' name='activo' value='". $curso['abierto']."'>
                                <input type='submit' value='Activar'>
                                </form>
                            </td>";
                        }
                        echo "<td>
                                <form action='eliminar.php' method='post'>
                                <input type='hidden' name='code' value='". $curso['codigo']."'>
                                <input type='submit' value='Eliminar'>
                                </form>
                                </td>";
                        echo "</tr>";
                    }
                ?>
        </table>
        <strong><a href="panelAdmin.php" class="logOutCont" style='text-decoration: none;'>Volver al menú principal de administrador</a></strong>
        <br><br>
        <div class="logOutCont">
            <button><a  href="logout.php" style='color: white; text-decoration: none'>Cerrar Sesión</a></button>
        </div>
</html>