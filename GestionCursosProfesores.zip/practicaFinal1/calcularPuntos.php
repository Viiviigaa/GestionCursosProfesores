<?php
function calcularPuntos($cargo, $bilingue, $fecha, $coordinador, $grupo, $situacion){
    $puntos = 0;
    //Sumamos los puntos pertinentes en función del cargo
    switch ($cargo) {
        case 'director':
            $puntos +=2;
            break;
        case 'jefeEstudios':
            $puntos +=2;
            break;
        case 'secretario':
            $puntos += 2;
            break;
        case 'jefeDepartamento':
            $puntos += 1;
            break;
        default:
            break;
    }
    //Sumamos los puntos pertinentes en caso de ser coordinador
    if (isset($coordinador)) {
        $puntos += 4;
    }
    //Sumamos los puntos pertinentes en caso de pertenecer al programa bilingue
    if (isset($bilingue)){
        $puntos += 3;
    }
    //Sumanos los puntos pertinentes para el grupoTic
    if(isset($grupo)){
        $puntos += 3;
    }

    //Sumanos los puntos pertinentes si no está en paro
    
    if($situacion=='activo'){
        $puntos+=1;
    }
    
    if(calcularAntiguedad($fecha)){
        $puntos += 1;
    }
    

    return $puntos;
}
function calcularAntiguedad($fechaalt){

        $fecha = DateTime::createFromFormat('Y-m-d', $fechaalt);

        if (!$fecha){
            return false;
        } 

        $fechaActual = new DateTime();

        $diferencia = $fechaActual->diff($fecha);

        $anioDiff = $diferencia->y;

        if($anioDiff > 15){
            return true;
        }else{
            return false;
        }


    }