<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilosLogin.css">
    <title>Login</title>
<?php
    $tiempoSesion = 5; 

    // Array para almacenar los errores
    $errores = [];

    // Iniciar sesión
    session_start();

    if($_SERVER['REQUEST_METHOD'] == 'POST'){

    if(empty($_POST['usuario']) || empty($_POST['contraseña'])){
        $errores['login'] = "<h4 style='color:red'>Todos los campos son obligatorios</h4>";
    } else {
        $usuario = $_POST['usuario'];
        $contraseña = $_POST['contraseña'];
        try {
            $con = new PDO('mysql:host=localhost;dbname=cursoscp;charset=utf8','victor','1234',[PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        } catch (PDOException $e) {
            die("Error de conexión");
        }
        
        $stmt = $con->prepare("SELECT * FROM admin WHERE usuario = ? AND contraseña = ?");
        $stmt->execute([$usuario, $contraseña]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        if($admin){
            $_SESSION['admin'] = $admin['usuario'];
            header('location:panelAdmin.php');
            exit();
        }       
        $stmt = $con->prepare("SELECT * FROM solicitantes WHERE correo = ? AND password = ?");
        $stmt->execute([$usuario, $contraseña]);
        $usuarioEncontrado = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($usuarioEncontrado){
            $_SESSION['user'] = $usuarioEncontrado['dni'];
            header('location:panelUsuario.php');
            exit();
        }
        if(!$usuarioEncontrado && !$admin){
            $errores['login'] = "<h4 style='color:red'>Credenciales incorrectas</h4>";
        }     
    }
}
?>
</head>
<body>
    <div id="formulario">
        <form action="login.php" method="POST">
            <h3>Login</h3>
            <div class="form-group"> 
                <label for="">Nombre de usuario</label>
                <input type="text" name="usuario" class="input">
            </div>

            <div class="form-group"> 
                <label for="">Contraseña</label>
                <input type="password" name="contraseña" class="input">
            </div>       
            <input type="submit" value="Login" id="submit">
        </form>
        <?php
            if(isset($errores['login'])){
                echo $errores['login'];
            }
        ?>
    </div>
    <h4 id="back" ><a href="index.php" style='text-decoration: none'>Volver al menú principal</a></h4>
</body>
</html>
