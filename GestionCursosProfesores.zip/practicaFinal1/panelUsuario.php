<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel administrador</title>
    <link rel="stylesheet" href="css/styles.css">   
    <?php
        session_start();
        $con = new PDO('mysql:host=localhost;dbname=cursoscp;charset=utf8', 'victor', '1234');
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    ?>
</head>
<body>
    <h2>Cursos</h2>
    <h3>Buscar cursos por fecha y disponibilidad</h3>
    <div class="logOutCont">
        <form action='panelUsuario.php' method='post'>
            <input type='date' name='fechaSolicitada' style='padding: 15px ; border-radius: 4px'>
            <input type='submit' value='Buscar cursos'>
        </form>
    </div>
    <?php
        if($_SERVER['REQUEST_METHOD']=='POST'){           
            echo "<table>
            <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Abierto</th>
                <th>Número de plazas</th>
                <th>Plazo de inscripción</th>
                <th>Inscripción</th>
            </tr>";

            $fechaInput = $_POST['fechaSolicitada'];
            $hoy = date('Y-m-d', strtotime($fechaInput));

            $stmt = $con->query("SELECT * FROM cursos where plazoinscripcion> '$hoy' and abierto='1'");
            $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($cursos as $curso){
                echo "<tr>";
                echo "<td>{$curso['codigo']}</td>";
                echo "<td>{$curso['nombre']}</td>";
                echo "<td>{$curso['abierto']}</td>";
                echo "<td>{$curso['numeroplazas']}</td>";
                echo "<td>{$curso['plazoinscripcion']}</td>";  
                echo "<td><form action='inscripcion.php' method='post'>
                            <input type='hidden' name='dniLog' value='" . $_SESSION['user'] ."'>
                            <input type='hidden' name='codigoCurso' value='". $curso['codigo'] ."'>
                            <input type='hidden' name='nombreCurso' value='". $curso['nombre'] ."'>
                            <input type='submit' value='Inscribirse'>
                          </form>
                      </td>"; 
                echo "</tr>";
            }               
        echo "</table>";
        }                    
    ?>
    <br>
    <div class="logOutCont">
        <button><a  href="logout.php" style='color: white; text-decoration: none'>Cerrar Sesión</a></button>
    </div>
</body>
</html>