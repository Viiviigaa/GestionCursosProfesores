<?php
    include('ordenarSolicitudes.php');
    session_start();
    if(!isset($_SESSION['admin'])){
        header('Location: login.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Document</title>
</head>
<body>
    <h3>Listado de admitidos</h3>
   <?php
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            $codigoCurso = $_POST['code'];
            $numPlazas = $_POST['numPlazas'];  
            $dnis = array(); 
            echo "<table>";
            echo "<tr>";
                echo "<th>DNI</th>";
                echo "<th>Nombre</th>";
                echo "<th>Apellidos</th>";
                echo "<th>Puntos</th>";
                echo "<th>Admitido</th>";
                echo "<th>Admitido previamente</th>";
            echo "</tr>";

            $listado = ordenarSolicitudesPorPuntos($codigoCurso,$numPlazas);
            foreach ($listado as $alumno) {
                echo "<tr>";
                echo "<td> {$alumno['dni']}</td>";
                $dnis[] = $alumno['dni'];
                echo "<td> {$alumno['nombre']}</td>";
                echo "<td> {$alumno['apellidos']}</td>";
                echo "<td> {$alumno['puntos']}</td>";
                echo "<td> {$alumno['admitido']}</td>";
                echo "<td> {$alumno['admitidosPrev']}</td>";
                echo "</tr>"; 
            }
            echo "</table>";
            $dniString = implode(',',$dnis);
        }
   ?>
    <div class="logOutCont">
        <form action="confirmarListadoAdmitidos.php" method="post">
            <input type="hidden" name='dnis' value='<?= $dniString ?>'>
            <input type="hidden" name='numPlazas' value='<?= $numPlazas ?>'>
            <input type="hidden" name='code' value='<?= $codigoCurso ?>'>
            <input type="submit" value='Confirmar admitidos' style='width: auto'>
        </form>
    </div>
    <br>
    <strong><a href="panelAdmin.php" class="logOutCont" style='text-decoration: none;'>Volver al menú principal de administrador</a></strong>
    <br>
    <div class="logOutCont">
        <button><a  href="logout.php" style='color: white; text-decoration: none'>Cerrar Sesión</a></button>
    </div>
</body>
</html>