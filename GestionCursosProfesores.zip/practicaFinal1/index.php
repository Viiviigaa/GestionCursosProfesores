<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Inicio</title>
</head>
<body>
    <header>
        <img src="img/logo-educamadrid.png" alt="Logo" id="logo">
        <div id="botones">
            <button><a href="registro.php" class="enlaces">Registrarse</a></button>
            <button><a href="login.php" class="enlaces">Login</a></button>
        </div>
    </header>
    <main>
        <h3>Cursos disponibles actualmente para profesores</h3>
        <table>
            <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Abierto</th>
                <th>Número de plazas</th>
                <th>Plazo de inscripción</th>
                <?php 
                    $con = new PDO('mysql:host=localhost;dbname=cursoscp;charset=utf8', 'victor', '1234');
                    $stmt = $con->query("SELECT * FROM cursos");
                    $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    foreach($cursos as $curso){
                        echo "<tr>";
                        echo "<td>{$curso['codigo']}</td>";
                        echo "<td>{$curso['nombre']}</td>";
                        echo "<td>{$curso['abierto']}</td>";
                        echo "<td>{$curso['numeroplazas']}</td>";
                        echo "<td>{$curso['plazoinscripcion']}</td>";
                        echo "</tr>";
                    }
                ?>
        </table>
    </main>
</body>
</html>