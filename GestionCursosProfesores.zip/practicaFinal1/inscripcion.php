<?php
    include('enviarEmail.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Inscripcion</title>
</head>
<body>
    <?php
        $con = new PDO('mysql:host=localhost;dbname=cursoscp;charset=utf8', 'victor', '1234');
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        //Recuperamos todas las variables necesarias para poder insertar la solicitud en la tabla y procedemos a ello
        $dni = $_POST['dniLog'];
        $codigoCurso = $_POST['codigoCurso'];
        $nombreCurso = $_POST['nombreCurso'];
        $hoy = date('Y-m-d');

        function encontrarCorreo($con,$dni){
            $stmt=$con->prepare("SELECT correo FROM solicitantes where dni = ?");
            $stmt->execute([$dni]);
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado['correo'];
        }
        $correo = encontrarCorreo($con, $dni);

        function insertarSolicitud($DNI, $codigoCurso, $fecha, $con){
            $consulta = "Insert into solicitudes values (?, ?, ?, ?)";
            $stmt = $con->prepare($consulta);
            return $stmt->execute([$DNI, $codigoCurso, $fecha, 0]);
        }
        
        if(insertarSolicitud($dni, $codigoCurso, $hoy, $con)){
            enviarEmail($correo,'Confirmación',"Te has inscrito con exito en $nombreCurso",'');
            echo "<div class='contenedor'>
                    <br>
                    <h3>Solicitud realizada correctamente!</h3>
                    <strong><a href='index.php' style='text-decoration: none'>Volver al listado de cursos</a></strong>
                  </div>";
        }else{
            echo "<div class='contenedor'>
                    <h3>Ha ocurrido un error con la solicitud</h3>
                    <strong><a href='index.php' style='text-decoration: none';>Volver al listado de cursos</a></strong>
                  </div>";
        }
    ?>
</body>
</html>