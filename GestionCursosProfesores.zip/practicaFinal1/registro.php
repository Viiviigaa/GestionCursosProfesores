<?php
    include('calcularPuntos.php');
    include('enviarEmail.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilosRegistro.css">
    <title>Document</title>
</head>
<?php
    $errores = array();
    if($_SERVER['REQUEST_METHOD']=='POST'){
        //Validamos que el campo del DNI no este vacío
        if(empty($_POST['dni'])){
            $errores['dni'] = "<h4 style='color:red'>El campo DNI no puede estar vacío</h4>";
        }
        //Validamos que el campo del DNI tenga el formato correcto
        if (!preg_match('/^[0-9]{8}[A-Z]$/', $_POST['dni'])) {
            $errores['dni'] = "<h4 style='color:red'>Introduce un DNI con formato válido</h4>";
        }
        //Validamos que el campo del nombre no este vacío
        if(empty($_POST['nombre'])){
            $errores['nombre'] = "<h4 style='color:red'>El campo nombre no puede estar vacío</h4>";
        }
        //Validamos que el campo de los apellidos no este vacío
        if(empty($_POST['apellidos'])){
            $errores['apellidos'] = "<h4 style='color:red'>El campo apellido no puede estar vacío</h4>";
        }
        //Validamos que el numero de telefono solo pueda contener 9 numeros
        if (!preg_match('/^[0-9]{9}$/', $_POST['telefono'])) {
            $errores['telefono'] = "<h4 style='color:red'>Introduce un telefono con formato válido</h4>";
        }
        //Validamos que el correo no este vacío
        if(empty($_POST['correo'])){
            $errores['correo']= "<h4 style='color:red'>El campo no puede estar vacío</h4>";
        }
        //Validamos que el codigo del centro sean 8 digitos numericos
        if (!preg_match('/^[0-9]{8}$/', $_POST['codigoCentro'])) {
            $errores['codigoCentro'] = "<h4 style='color:red'>Introduce un formato válido para el código del centro </h4>";
        }
        //Comprobamos que el campo no este vacio
        if(empty($_POST['nGrupo'])){
            $errores['nGrupo'] = "<h4 style='color:red'>El campo no puede estar vacío</h4>";
        }
    }
?>
<body>
    <div id="formulario">
        <h3>Registro</h3>
        <form action="registro.php" method="post">

            <div class="form-group">
                <label for="">DNI *</label>
                <input type="text" name="dni" value="<?= isset($_POST['dni'])?htmlspecialchars($_POST['dni']):'' ?>" class="input">
                <?php 
                    if(isset($errores['dni'])){
                        echo $errores['dni'];
                    }
                ?>
            </div>

            <div class="form-group">
                <label for="">Nombre * </label>
                <input type="text" name="nombre" value="<?= isset($_POST['nombre'])?htmlspecialchars($_POST['nombre']):'' ?>" class="input" id="fila">       
                <?php 
                    if(isset($errores['nombre'])){
                        echo $errores['nombre'];
                    }
                ?>
            </div>

            <div class="form-group">
                <label for="">Apellidos *</label>
                <input type="text" name="apellidos" value="<?= isset($_POST['apellidos'])?htmlspecialchars($_POST['apellidos']):'' ?>" class="input">
                <?php 
                    if(isset($errores['apellidos'])){
                        echo $errores['apellidos'];
                    }
                ?>
            </div>

            <div class="form-group">
                <label for="">Telefono *</label>
                <input type="text" name="telefono" value="<?=isset($_POST['telefono'])?htmlspecialchars($_POST['telefono']):'' ?>"class="input">
                <?php 
                if(isset($errores['telefono'])){
                    echo $errores['telefono'];
                }
            ?>
            </div>
            <div class="form-group">
                <label for="">Correo electrónico</label>
                <input type="email" name="correo" value="<?= isset($_POST['correo'])?htmlspecialchars($_POST['correo']):'' ?>" class="input">
            </div>

            <div class="form-group">
                <label for="">Contraseña</label><br>
                <input type="password" name="passw" value="<?= isset($_POST['passw'])?htmlspecialchars($_POST['passw']):'' ?>" class="input"><br><br>
            </div>

            <div class="form-group">
                <label for="">Codigo del centro *</label>         
                <input type="text" name="codigoCentro" value="<?= isset($_POST['codigoCentro'])?htmlspecialchars($_POST['codigoCentro']):'' ?>" class="input">
                <?php 
                    if(isset($errores['codigoCentro'])){
                        echo $errores['codigoCentro'];
                    }
                ?>
            </div>

            <div class="form-group">
                <label for="">Nombre del grupo</label>
                <input type="text" name="nGrupo" value="<?= isset($_POST['nGrupo'])?htmlspecialchars($_POST['nGrupo']):'' ?>" class="input">
            </div>

            <div class="form-group">
                <label for="">Especialidad</label><br>
                <input type="text" name="especialidad" value="<?= isset($_POST['especialidad'])?htmlspecialchars($_POST['especialidad']):'' ?>" class="input"><br><br>
            </div>
            
            <div class="form-group">
            <label for="">Cargo</label><br>
                <select name="cargo">
                    <option value="profesor">Profesor</option>
                    <option value="director">Director</option>
                    <option value="jefeEstudios">Jefe de estudios</option>
                    <option value="secretario">Secretario</option>
                    <option value="jefeDepartamento">Jefe de departamento</option>
            </select>
            </div>
            <div class="form-group">
                <label for="">Situacion</label><br>
                <select name="situacion">
                    <option value="activo">activo</option>
                    <option value="inactivo">inactivo</option>
                </select><br>
            </div>

            <div class="form-group">
                <label for="">Fecha de nacimiento</label>
                <input type="date" name="fechaN"><br>
            </div> 

            <div class="form-group">
                <label for="">Cargo</label>
                <input type="checkbox" name="esCargo" class="input" value='<?php $_POST['esCargo']?>'>
            </div>

            <div class="form-group">
                <label for="">Coordinador TIC</label>
                <input type="checkbox" name="coordinador" class="input" value='<?php $_POST['coordinador']?>'>
            </div>

            <div class="form-group">
                <label for="">Grupo TIC</label>
                <input type="checkbox" name="grupo" class="input" value='<?php $_POST['grupo']?>'>
            </div>

            <div class="form-group">
                <label for="">Pbilin</label><br>
                <input type="checkbox" name="pbilib" class="input" value='<?php $_POST['pbilib']?>'><br>
            </div>                  
            <input type="submit" value="Continuar" id="submit"><br><br>
        </form>
        <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($errores)) {     
                $dni = $_POST['dni'];
                $nombre = $_POST['nombre'];
                $apellidos = $_POST['apellidos'];
                $telefono = $_POST['telefono'];
                $correo = $_POST['correo'];
                $codigoCentro = $_POST['codigoCentro'];
                $nGrupo = $_POST['nGrupo'];
                $especialidad = $_POST['especialidad'];
                $cargo  = $_POST['cargo'];
                $contraseña   = $_POST['passw'];            
                $fechaN  = $_POST['fechaN'];
                $situacion  = trim($_POST['situacion']);
               
                $coordinador = isset($_POST['coordinador']) ? 1 : 0;
                $grupoTic    = isset($_POST['grupo'])       ? 1 : 0;
                $esCargo     = isset($_POST['esCargo'])     ? 1 : 0;
                $bilingue    = isset($_POST['pbilib'])      ? 1 : 0;

                $puntos = calcularPuntos($cargo, $bilingue, $fechaN, $coordinador, $grupoTic, $situacion);

                try {              
                    function insertarSolicitante($dni, $apellidos, $nombre, $telefono, $correo, $codigoCentro, $coordinador, $grupoTic, $nGrupo, $bilingue, $esCargo, $cargo, $situacion, $fechaN, $especialidad, $puntos, $contraseña) {     
                        $con = new PDO('mysql:host=localhost;dbname=cursoscp;charset=utf8', 'victor', '1234');
                        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);                                         
                        $consulta = "INSERT INTO solicitantes VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";    
                        $stmt = $con->prepare($consulta);
                        $stmt->execute([$dni, $apellidos, $nombre, $telefono, $correo, $codigoCentro, $coordinador, $grupoTic, $nGrupo, $bilingue, $esCargo, $cargo, $situacion, $fechaN, $especialidad, $puntos, $contraseña]);                    
                    }  
                insertarSolicitante($dni, $apellidos, $nombre, $telefono, $correo, $codigoCentro, $coordinador, $grupoTic, $nGrupo, $bilingue, $esCargo, $cargo, $situacion, $fechaN, $especialidad, $puntos, $contraseña); 
                echo "<h3>Has obtenido: $puntos/14 puntos</h3>";               
                echo "<h4 style='color:green'>Datos introducidos correctamente en la base de datos</h4>";
                } catch (PDOException $e) {  
                    echo "<h4 style='color:red'>Error al insertar: ". $e->getMessage()."</h4>";
                }
                           
                enviarEmail($correo,'Confirmación',"Su cuenta ha sido registrada con éxito.",'');
                }              
                ?>
            </div>
            <h4 id="back" ><a href="index.php" style='text-decoration: none'>Volver al menú principal</a></h4>
    </body>
 </html>