<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel administrador</title>
    <link rel="stylesheet" href="css/styles.css">    
    <?php
        $con = new PDO('mysql:host=localhost;dbname=cursoscp;charset=utf8', 'victor', '1234');
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    ?>  
</head>
<?php
    session_start();
    if(!isset($_SESSION['admin'])){
        header('location:login.php');
        exit();
    }
?>
<body>
    <h3>Cursos</h3>
    <table>
            <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Abierto</th>
                <th>Número de plazas</th>
                <th>Plazo de inscripción</th>
                <th>Activar/Desactivar</th>
                <th>Eliminar</th>
                <th>Mostrar listado</th>
            </tr>
                <?php 
                    $stmt = $con->query("SELECT * FROM cursos");
                    $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    foreach($cursos as $curso){
                        echo "<tr>";
                        echo "<td>{$curso['codigo']}</td>";
                        echo "<td>{$curso['nombre']}</td>";
                        echo "<td>{$curso['abierto']}</td>";
                        echo "<td>{$curso['numeroplazas']}</td>";
                        echo "<td>{$curso['plazoinscripcion']}</td>";
                        if($curso['abierto']){
                            echo "<td>
                                <form action='actualizar.php' method='post'>
                                <input type='hidden' name='code' value='". $curso['codigo']."'>
                                <input type='hidden' name='activo' value='". $curso['abierto']."'>
                                <input type='submit' value='Desactivar'>
                                </form>
                            </td>";
                        }else if(!$curso['abierto']){
                            echo "<td>
                                <form action='actualizar.php' method='post'>
                                <input type='hidden' name='code' value='". $curso['codigo']."'>
                                <input type='hidden' name='activo' value='". $curso['abierto']."'>
                                <input type='submit' value='Activar'>
                                </form>
                            </td>";
                        }
                        echo "<td>
                                <form action='eliminar.php' method='post'>
                                    <input type='hidden' name='code' value='". $curso['codigo']."'>
                                    <input type='submit' value='Eliminar'>
                                </form>
                                </td>";
                        echo "<td>
                                <form action='mostrarListados.php' method='post'>
                                    <input type='hidden' name='code' value='". $curso['codigo']."'>
                                    <input type='hidden' name='numPlazas' value='". $curso['numeroplazas']."'>
                                    <input type='submit' value='Admitidos'>
                                </form>
                                </td>";                                               
                        "</tr>";
                    }
                ?>
        </table>
        <div id="formulario">
            <h3>Añadir cursos</h3>
            <form action='incorporar.php' method='post' id="formulario">
            <div class="form-group">
                <label>Nombre del curso</label><br>
                <input type='text' name='nombreCurso'><br>
            </div>
            
            <div class="form-group">
                <input type='checkbox' name='activo'><label>Abierto</label><br>
            </div>
            
            <div class="form-group">
                <label>Numero de plazas</label><br>
                <input type='number' name='numPlazas'><br>
            </div>
            
            <div class="form-group">
                <label>Plazo de inscripción</label><br>
                <input type='date' name='inscripcion'><br>
             </div>
            <input type='submit' value='Añadir curso'>
        </form>
        </div>
        <br>
        <div class="logOutCont">
            <button><a  href="logout.php" style='color: white; text-decoration: none'>Cerrar Sesión</a></button>
        </div>
</body>
</html>