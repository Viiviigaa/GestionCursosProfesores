<?php
session_start();
session_unset();  
session_destroy();  
setcookie("sesion_expira", "", time() - 3600, "/");
header("Location: login.php");
exit();
?>
