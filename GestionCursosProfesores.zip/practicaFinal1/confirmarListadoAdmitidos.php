<?php
    include('ordenarSolicitudes.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Admitidos</title>
</head>
<body>
    <?php
        if($_SERVER['REQUEST_METHOD']=='POST'){
        session_start();
        try{
            $con = new PDO('mysql:host=localhost;dbname=cursoscp;charset=utf8', 'victor', '1234');
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            if(!isset($_SESSION['admin'])){
                header('Location: login.php');
                exit();
            }
            //Es un único string que hay que dividir por el separador ','
            $dnis = $_POST['dnis'];
            //Separo cada uno de los dnis y se mete en un array
            $arrayDnis = explode(',',$dnis);   
            //Codigo del curso
            $codigoCurso= $_POST['code'];
            //Número de plazas
            $numPlazas = $_POST['numPlazas'];
            $sql = "UPDATE solicitudes SET ADMITIDO = 1  WHERE codigocurso = ? and dni = ?";
            $stmt= $con->prepare($sql);
            foreach($arrayDnis as $dni){
                $stmt->execute([$codigoCurso,$dni]);
            }
            }catch(PDOException $e){
            echo "Ha ocurrido un error en base de datos: " . $e->getMessage();
            }

            echo "<table>";
                echo "<tr>";
                    echo "<th>DNI</th>";
                    echo "<th>Nombre</th>";
                    echo "<th>Apellidos</th>";
                    echo "<th>Puntos</th>";
                    echo "<th>Admitido</th>";
                    echo "<th>Admitido previamente</th>";
                echo "</tr>";
                $listado = ordenarSolicitudesPorPuntos($codigoCurso, $numPlazas);
                foreach ($listado as $alumno) {
                echo "<tr>";
                    echo "<td> {$alumno['dni']}</td>";
                    echo "<td> {$alumno['nombre']}</td>";
                    echo "<td> {$alumno['apellidos']}</td>";
                    echo "<td> {$alumno['puntos']}</td>";
                    echo "<td> {$alumno['admitido']}</td>";
                    echo "<td> {$alumno['admitidosPrev']}</td>";
                echo "</tr>"; 
                }
            echo "</table>";
            echo "<br><strong><a href='panelAdmin.php' class='logOutCont' style='text-decoration: none;'>Volver al menú principal de administrador</a></strong>";
            echo "<div class='logOutCont'>
                    <button><a  href='logout.php' style='color: white; text-decoration: none'>Cerrar Sesión</a></button>;
                 </div>";
    }
    ?>
</body>
</html>